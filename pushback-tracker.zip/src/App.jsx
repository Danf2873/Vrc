import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Team from "./pages/Team";
import Event from "./pages/Event";
import Match from "./pages/Match";
import Manual from "./pages/Manual";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/team/:id" element={<Team />} />
        <Route path="/event/:id" element={<Event />} />
        <Route path="/match/:id" element={<Match />} />
        <Route path="/manual" element={<Manual />} />
      </Routes>
    </BrowserRouter>
  );
}