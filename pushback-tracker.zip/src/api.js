const API_TOKEN = "YOUR_API_TOKEN_HERE";

export async function apiFetch(endpoint) {
  const res = await fetch(`https://www.robotevents.com/api/v2/${endpoint}`, {
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${API_TOKEN}`,
    },
  });
  return res.json();
}