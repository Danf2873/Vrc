import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { apiFetch } from "../api";

export default function Team() {
  const { id } = useParams();
  const [team, setTeam] = useState(null);

  useEffect(() => {
    apiFetch(`teams?number[]=${id}&program[]=41`).then((data) => {
      setTeam(data.data[0]);
    });
  }, [id]);

  if (!team) return <p className="p-4">Loading...</p>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">{team.team_name}</h1>
      <p>{team.number} — {team.organization}</p>
      <p>{team.city}, {team.region}</p>
    </div>
  );
}