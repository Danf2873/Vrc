import { useState } from "react";

export default function Match() {
  const [longGoal, setLongGoal] = useState(0);
  const [topCenter, setTopCenter] = useState(0);
  const [bottomCenter, setBottomCenter] = useState(0);
  const [auton, setAuton] = useState(false);
  const [park, setPark] = useState(false);
  const [doublePark, setDoublePark] = useState(false);
  const [notes, setNotes] = useState(localStorage.getItem("notes") || "");

  const score =
    longGoal * 10 +
    topCenter * 8 +
    bottomCenter * 6 +
    (auton ? 6 : 0) +
    (park ? 8 : 0) +
    (doublePark ? 30 : 0);

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Match Scoring</h1>
      <div className="space-y-2">
        <label>Long Goal CP: <input type="number" value={longGoal} onChange={(e) => setLongGoal(+e.target.value)} /></label>
        <label>Top Center CP: <input type="number" value={topCenter} onChange={(e) => setTopCenter(+e.target.value)} /></label>
        <label>Bottom Center CP: <input type="number" value={bottomCenter} onChange={(e) => setBottomCenter(+e.target.value)} /></label>
        <label><input type="checkbox" checked={auton} onChange={(e) => setAuton(e.target.checked)} /> Auton</label>
        <label><input type="checkbox" checked={park} onChange={(e) => setPark(e.target.checked)} /> Park</label>
        <label><input type="checkbox" checked={doublePark} onChange={(e) => setDoublePark(e.target.checked)} /> Double Park</label>
        <p className="font-bold">Total Score: {score}</p>
      </div>
      <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="border w-full h-24 mt-4"></textarea>
      <button onClick={() => localStorage.setItem("notes", notes)} className="bg-green-500 text-white px-4 py-2 mt-2">Save Notes</button>
    </div>
  );
}