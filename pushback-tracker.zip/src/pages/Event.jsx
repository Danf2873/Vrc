import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { apiFetch } from "../api";

export default function Event() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);

  useEffect(() => {
    apiFetch(`events?sku=${id}`).then((data) => {
      setEvent(data.data[0]);
    });
  }, [id]);

  if (!event) return <p className="p-4">Loading...</p>;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">{event.name}</h1>
      <p>{event.start}</p>
      <p>{event.location}</p>
    </div>
  );
}