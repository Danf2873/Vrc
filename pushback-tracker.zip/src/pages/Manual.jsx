export default function Manual() {
  return (
    <div className="p-4 h-screen">
      <iframe
        src="https://link-to-vex-push-back-manual.pdf"
        className="w-full h-full"
        title="Game Manual"
      />
    </div>
  );
}